package com.javabank.javabank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavabankApplicationTests {

	@Test
	void contextLoads() {
	}

}
